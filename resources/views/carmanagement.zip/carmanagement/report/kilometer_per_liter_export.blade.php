<table>  
    <tbody>
           <tr>
              <td></td>
              <td></td>
              <td style="background:#998912"><b>YGN Office Driver</b></td>
              <td style="background:#43e8a3"><b>YGN Contract Driver</b></td>
           </tr>
           <tr>
              <td></td>
              <td></td>
              <td style="background:#eff450"><b>NPT Office Driver</b></td>
              <td style="background:#E0A800"><b>NPT Contract Driver</b></td>
           </tr>           
           <tr>
           </tr>
           <tr>
             <td colspan="9"><b>Detail Information</b></td>
             <td colspan="50">Monthly usage Kilometer/ Liter</td>
          </tr> 
          <tr>
                <td rowspan="2"><b>No</b></td>
                <td rowspan="2"><b>Dept</b></td>
                <td rowspan="2"><b>Main User</b></td>
                <td rowspan="2"><b>Car</b></td>
                <td rowspan="2"><b>Car No</b></td>
                <td rowspan="2"><b>Driver</b></td>
                <td rowspan="2"><b>Model Year</b></td>
                <td rowspan="2"><b>Car Parking</b></td>
                <td colspan="4"><b>Apr</b></td>
                <td colspan="4"><b>May</b></td>
                <td colspan="4"><b>June</b></td>
                <td colspan="4"><b>July</b></td>
                <td colspan="4"><b>Aug</b></td>
                <td colspan="4"><b>Sep</b></td>
                <td colspan="4"><b>Oct</b></td>
                <td colspan="4"><b>Nov</b></td>
                <td colspan="4"><b>Dec</b></td>
                <td colspan="4"><b>Jan</b></td>
                <td colspan="4"><b>Feb</b></td>
                <td colspan="4"><b>Mar</b></td>
                <td colspan="3"><b>Total</b></td>
            </tr>
            <tr>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td> 
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>Current <br>KM</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
               <td><b>KM</b></td>   
               <td><b>L</b></td>
               <td><b>KM/L</b></td>
            </tr>
           <?php  $i = 1; ?>
           @foreach($cars as $car)
              <tr>
                <td>{{ $i }}</td>
                <td>{{ $car->department_name }}</td>
                <td>{{ $car->main_user_name }}</td>
                <td style="background:#998912;">{{ $car->car_type }}</td>
                <td>{{ $car->car_number }}</td>
                @if($car->employee_type_id == 2)
                <td style="background:#998912">{{ $car->driver_name }}</td>
                @elseif($car->employee_type_id == 3)
                 <td style="background:#43e8a3">{{ $car->driver_name }}</td>
                  @elseif($car->employee_type_id == 5)
                 <td style="background:#eff450">{{ $car->driver_name }}</td>
                 @elseif($car->employee_type_id == 6)
                 <td style="background:#E0A800">{{ $car->driver_name }}</td>
                 @endif
                   <td>{{ $car->model_year }}</td>
                   <td>{{ $car->parking }}</td>
                    <td>{{ $car->april_total_current_km }}</td>
	                <td>{{ $car->april_total_km }}</td>
	                <td>{{ $car->april_total_liter }}</td>
                    <td>{{ $car->april_per_km }}</td>
                    <td>{{ $car->may_total_current_km }}</td>
	                <td>{{ $car->may_total_km }}</td>
	                <td>{{ $car->may_total_liter }}</td>
                    <td>{{ $car->may_per_km }}</td>
                    <td>{{ $car->june_total_current_km }}</td>
	                <td>{{ $car->june_total_km }}</td>
	                <td>{{ $car->june_total_liter }}</td>
                    <td>{{ $car->june_per_km }}</td>
                    <td>{{ $car->july_total_current_km }}</td>
	                <td>{{ $car->july_total_km }}</td>
	                <td>{{ $car->july_total_liter }}</td>
                    <td>{{ $car->july_per_km }}</td>
                    <td>{{ $car->august_total_current_km }}</td>
	                <td>{{ $car->august_total_km }}</td>
	                <td>{{ $car->august_total_liter }}</td>
                    <td>{{ $car->august_per_km }}</td>
                    <td>{{ $car->sep_total_current_km }}</td>
	                <td>{{ $car->sep_total_km }}</td>
	                <td>{{ $car->sep_total_liter }}</td>
                    <td>{{ $car->sep_per_km }}</td>
                    <td>{{ $car->oct_total_current_km }}</td>
	                <td>{{ $car->oct_total_km }}</td>
	                <td>{{ $car->oct_total_liter }}</td>
                    <td>{{ $car->oct_per_km }}</td>
                    <td>{{ $car->nov_total_current_km }}</td>
	                <td>{{ $car->nov_total_km }}</td>
	                <td>{{ $car->nov_total_liter }}</td>
                    <td>{{ $car->nov_per_km }}</td>
                    <td>{{ $car->dec_total_current_km }} </td>
	                <td>{{ $car->dec_total_km }} </td>
	                <td>{{ $car->dec_total_liter }}</td>
                    <td>{{ $car->dec_per_km }}</td>
                    <td>{{ $car->jan_total_current_km }}</td>
	                <td>{{ $car->jan_total_km }}</td>
	                <td>{{ $car->jan_total_liter }}</td>
                    <td>{{ $car->jan_per_km }}</td>
                    <td>{{ $car->feb_total_current_km }}</td>
	                <td>{{ $car->feb_total_km }}</td>
	                <td>{{ $car->feb_total_liter }}</td>
                    <td>{{ $car->feb_per_km }}</td>
                    <td>{{ $car->march_total_current_km }}</td>
	                <td>{{ $car->march_total_km }}</td>
	                <td>{{ $car->march_total_liter }}</td>
                    <td>{{ $car->march_per_km }}</td>
                    <!-- total -->
                    <td>{{ $car->april_total_km +  $car->may_total_km +  $car->june_total_km +  $car->july_total_km +
                         $car->august_total_km +  $car->sep_total_km + $car->oct_total_km + $car->nov_total_km 
                         + $car->dec_total_km + $car->jan_total_km + $car->feb_total_km  + $car->march_total_km }}</td>

                    <td>{{ $car->april_total_liter + $car->may_total_liter + $car->june_total_liter + $car->july_total_liter
                        + $car->august_total_liter + $car->sep_total_liter + $car->oct_total_liter + $car->nov_total_liter 
                        + $car->dec_total_liter + $car->jan_total_liter + $car->်နဘ_total_liter + $car->march_total_liter }}</td>

                    <td>{{ $car->april_per_km + $car->may_per_km + $car->june_per_km + $car->july_per_km 
                        + $car->august_per_km + $car->sep_per_km + $car->oct_per_km + $car->nov_per_km
                        + $car->dec_per_km  + $car->jan_per_km + $car->feb_per_km + $car->march_per_km}}</td>


              </tr>
              
               
             
            <?php  $i++; ?>
           @endforeach
</tbody>
</table>