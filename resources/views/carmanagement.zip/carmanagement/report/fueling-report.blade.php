<table>  
    <tbody>
          
           <tr>
              <td colspan="8"><b>NPT Office Driver</b></td>
           </tr> 
           <tr>
             <td colspan="8"><b>Car No :</b></td>
          </tr>
          <tr>
             <td colspan="8"><b>Driver Name :</b></td>
          </tr> 
          <tr>
                <td><b>Date</b></td>
                <td><b>Mileage Meter</b></td>
                <td><b>Mileage Difference</b></td>
                <td><b>Liter</b></td>
                <td><b>Rate (Kyats)</b></td>
                <td><b>Gasoline filled driver's name</b></td>
                <td><b>User officer's Sign</b></td>
            </tr>
           <?php  $i = 1; ?>
           @foreach($cars as $car)
              <tr>
                <td>{{ $car->date }}</td>
                <td></td>
                <td></td>
                <td>{{ $car->liter }}</td>
                <td>{{ $car->car_number }}</td>
                <td>{{ $car->model_year }}</td>
                <td>{{ $car->parking }}</td>
              </tr>
              
              
</tbody>
</table>