<table>  
    <tbody>

           <tr>
              <td></td>
              <td></td>
              <td style="background:#998912">YGN Office Driver</td>
              <td style="background:#43e8a3">YGN Contract Driver</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td style="color:red">Month</td>
           </tr>
           <tr>
              <td></td>
              <td></td>
              <td style="background:#eff450;border:5px;">NPT Office Driver</td>
              <td style="background:#E0A800;border:5px">NPT Contract Driver</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td>{{ $month }}</td>
           </tr>
          <tr>
              <td colspan="8"><b>Detail Information</b></td>
              <td><b>Different Kilometer for periodic maintenance</b></td>
          </tr>

          <tr>
                <td><b>No</b></td>
                <td><b>Dept</b></td>
                <td><b>Main User</b></td>
                <td><b>Car</b></td>
                <td><b>Car No</b></td>
                <td><b>Driver</b></td>
                <td><b>Model Year</b></td>
                <td><b>Car Parking</b></td>
                <td><b>Current Kilo - Maintenance Kilo</b></td>
            </tr>
           <?php  $i = 1; ?>
           @foreach($km_for_maintenances as $km_for_maintenance)
              <tr>
                <td>{{ $i }}</td>
                <td>{{ $km_for_maintenance->department_name }}</td>
                <td>{{ $km_for_maintenance->main_user_name }}</td>
                <td>{{ $km_for_maintenance->car_type }}</td>
                <td>{{ $km_for_maintenance->car_number }}</td>
                <td>{{ $km_for_maintenance->driver_name }}</td>
                <td>{{ $km_for_maintenance->model_year }}</td>
                <td>{{ $km_for_maintenance->parking }}</td>

                <td>{{ $km_for_maintenance->current_km  }} - {{ $km_for_maintenance->kilo_meter }}</td>
              </tr>
              <?php $i++; ?>
              @endforeach
              
</tbody>
</table>