<?php

namespace App\Models\TaxManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RsIncomeTax extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'salary_id',
        'user_id',
        'salary',
        'income_tax_usd',
        'exchange_rate',
        'income_tax_mmk',
        'ssc',
        'percent_allowance',
        'max_allowance',
        'tax_calculation_percent',
        'remark'
    ];
}
