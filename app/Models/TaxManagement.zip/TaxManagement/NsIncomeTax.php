<?php

namespace App\Models\TaxManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NsIncomeTax extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'salary_id',
        'user_id',
        'salary',
        'ot',
        'leave',
        'adjustment',
        'total_income',
        'estimated_percent',
        'estimated_income',
        'estimated_income_round',
        'estimated_exchange_rate',
        'actual_percent',
        'actual_income',
        'actual_income_round',
        'actual_exchange_rate',
        'remark'
    ];
}
