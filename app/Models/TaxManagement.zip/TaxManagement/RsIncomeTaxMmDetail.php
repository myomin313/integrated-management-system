<?php

namespace App\Models\TaxManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RsIncomeTaxMmDetail extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'rs_income_tax_id',
        'user_id',
        'salary',
        'transfer_to_jp',
        'bonus',
        'salary_bonus',
        'oversea',
        'dc',
        'total_salary_usd',
        'exchange_rate',
        'total_salary_mmk'
    ];
}
