<?php

namespace App\Models\TaxManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RsIncomeTaxJpyDetail extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'rs_income_tax_id',
        'user_id',
        'salary',
        'transfer_from_mm',
        'adjustment',
        'income_tax_jpy',
        'bonus',
        'salary_bonus',
        'oversea',
        'dc',
        'total_salary_yen',
        'exchange_rate',
        'total_salary_mmk'
    ];
}
