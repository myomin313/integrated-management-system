<?php

namespace App\Models\TaxManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ssc extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'salary_id',
        'user_id',
        'salary',
        'employer_percent',
        'employer_amount',
        'employee_percent',
        'employee_amount',
        'total_percent',
        'total_amount',
        'remark'
    ];
}
